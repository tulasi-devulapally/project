#INSURANCE ANALYTICS PROJECT

-- 1. What is the total number of customers available in the policy database?
select count(*) as total_custmers from customerinformation;

-- 2.What is the total number of policies issued?
select count(*) as total_policies from policydetails;

-- 3.What is the total claim amount generated from all policies?
select sum(claimamount) as total_claims from claims;

-- 4. What is the average coverage amount per policy?
select avg(coverageamount) as avg_coverage_amount from policydetails;

-- 5. What is the average premium amount collected per policy?
select avg(premiumamount) as avg_premium_amount from policydetails;
 
 -- 6. What percentage of policies are currently active?
 select sum(status ="active")/count(*)*100 as percentage_of_activepolicies from policydetails;
 
 -- 7. How many policies are in active, lapsed, and terminated status?
 select status ,count(*) as policy_count from policydetails group by Status order by policy_count desc;
 
 -- 8. Which policy status has the highest number of policies?
 select status ,count(*) as policy_count from policydetails group by Status order by policy_count desc limit 1 ;
 
 -- 9. What is the ratio between active policies and inactive policies?
 select sum(status ="active") as active_policices,sum(status != "active") as inactive_policies,
 round((sum(status="active")/sum(status != "active") ),2) as ratio_bt_active_and_inactive_policies from policydetails;
 
-- 10.Which age group has the highest number of policies? 
select C.agegroup,count(p.policyid) as agegroup_wise_policies from customerinformation as c  join policydetails as p
 on c.customerid =p.customerid group by agegroup order by agegroup_wise_policies desc limit 1;

-- 11. Identify the top three age groups by policy count?
select C.agegroup,count(p.policyid) as agegroup_wise_policies from customerinformation as c join policydetails as p 
on c.customerid=p.customerid  group by agegroup order by agegroup_wise_policies desc limit 3;

-- 12.Which gender has the highest policy participation?
select c.gender ,count(p.policyid) as policy_count from customerinformation as c join policydetails as p on 
c.customerid = p.customerid group by gender order by policy_count desc limit 1; 

-- 13. What is the difference between male and female policy counts?
SELECT sum(GENDER="MALE") AS male_policies ,sum(gender="female") as female_policies ,(sum(gender="male")-sum(gender="female"))
 as diff_bt_male_and_female_policies from customerinformation ;
 
 -- 14. Which policy type has the maximum number of policies?
 select policytype ,count(policyid) as policytype_wise_policies from policydetails group by policytype order by policytype_wise_policies  desc limit 1;
 
 -- 15. Which policy type has the minimum number of policies?
 select policytype ,count(policyid) as policytype_wise_policies from policydetails group by policytype order by policytype_wise_policies   limit 1;
 
 -- 16. Compare Auto and Health policy counts?
 select sum(policytype="auto") as auto_policies, sum(policytype="health") as health_policies from policydetails;
 
 -- 17. What is the total number of policies across all policy types?
 select policytype,count(policyid) as policy_count from policydetails group by policytype order by policy_count desc;
 
 -- 18. What is the average premium growth rate over all years?
 WITH yearly_premium AS (
    SELECT
        policystartyear,
        AVG(premiumamount) AS avg_premium
    FROM policydetails
    GROUP BY policystartyear
),
growth AS (
    SELECT
        policystartyear,
        avg_premium,
        100.0 * (avg_premium - LAG(avg_premium) OVER (ORDER BY policystartyear))
            / NULLIF(LAG(avg_premium) OVER (ORDER BY policystartyear), 0) AS growth_rate_pct
    FROM yearly_premium
)
SELECT ROUND(AVG(growth_rate_pct), 2) AS avg_premium_growth_rate_pct
FROM growth
WHERE growth_rate_pct IS NOT NULL;


-- 19. Is the premium growth trend increasing or decreasing over time?
with yearly_premimum as (
select 
      policystartyear,
      avg(premiumamount) as avgpremimum
      from policydetails
      group by policystartyear
),
growth as(
select 
	policystartyear,
    avgpremimum,
    100.0 * (avgpremimum - LAG(avgpremimum) OVER (ORDER BY policystartyear))
        / NULLIF(LAG(avgpremimum) OVER (ORDER BY policystartyear), 0) AS growth_rate_pct
FROM yearly_premimum)
select policystartyear,avgpremimum,growth_rate_pct
from growth
ORDER BY policystartyear;
 
 -- 20.Calculate the difference between the highest and lowest premium growth rates?
 with yearly_premimum as(
 select
      policystartyear,
      avg(premiumamount) as avgpre
      from policydetails
      group by policystartyear),
  growth as (
  select
       policystartyear,
       avgpre,
       100*((avgpre)-lag(avgpre)over(order by policystartyear))/
       nullif(lag(avgpre)over(order by policystartyear),0) as growth_per
       from yearly_premimum)
select max(growth_per)-min(growth_per) as growth_range_pct
from growth where growth_per is not null;
       
       
 -- 21. What is the yearly trend of policies ending from 2016 to 2034?
 select 
   policyendyear,count(policyid)as end_policies from policydetails where policyendyear between 2016 and 2034
   group by policyendyear order by policyendyear;
 
 
 -- THE END