-- ============================================================
--  ZOMATO ANALYTICS PROJECT — QUESTIONNAIRE ANSWERS
-- ============================================================

USE zomato_analytics;


-- ============================================================
-- Q1. DATA MODEL
-- ============================================================
SELECT
  TABLE_NAME, COLUMN_NAME, CONSTRAINT_NAME,
  REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE TABLE_SCHEMA = 'zomato_analytics'
  AND REFERENCED_TABLE_NAME IS NOT NULL;


-- ============================================================
-- Q2. CALENDAR TABLE
-- ============================================================

-- Confirm date_dim fully covers main's date range
SELECT
  (SELECT MIN(Date) FROM main)     AS main_min_date,
  (SELECT MAX(Date) FROM main)     AS main_max_date,
  (SELECT MIN(Date) FROM date_dim) AS calendar_min_date,
  (SELECT MAX(Date) FROM date_dim) AS calendar_max_date;

-- Calendar table with formulas applied for display
SELECT
  DateKey,
  Date,
  Year,
  Month                              AS MonthNo,
  MonthName                          AS MonthFullName,
  CONCAT('Q', Quarter)               AS Quarter,
  DATE_FORMAT(YearMonth, '%Y-%b')    AS YearMonth,
  WeekdayNo,
  WeekdayName,
  CONCAT('FM', FinancialMonth)       AS FinancialMonth,
  CONCAT('FQ-', FinancialQuarter)    AS FinancialQuarter
FROM date_dim
ORDER BY Date
LIMIT 20;


-- ============================================================
-- Q3. AVERAGE COST FOR TWO -> USD
-- ============================================================
SELECT
  m.RestaurantID,
  m.RestaurantName,
  m.Currency,
  m.Average_Cost_for_two                                  AS Cost_Local,
  cur.USD_Rate,
  ROUND(m.Average_Cost_for_two * cur.USD_Rate, 2)          AS Cost_USD
FROM main m
JOIN currency cur ON m.Currency = cur.Currency
ORDER BY Cost_USD DESC
LIMIT 20;


-- ============================================================
-- Q4. RESTAURANT COUNT BY CITY AND COUNTRY
-- ============================================================
SELECT
  c.Countryname,
  m.City,
  COUNT(*) AS Restaurant_Count
FROM main m
JOIN country c ON m.CountryCode = c.CountryID
GROUP BY c.Countryname, m.City
ORDER BY Restaurant_Count DESC;


-- ============================================================
-- Q5. RESTAURANTS OPENED BY YEAR / QUARTER / MONTH
-- ============================================================
SELECT
  d.Year,
  CONCAT('Q', d.Quarter) AS Quarter,
  d.MonthName,
  COUNT(*) AS Restaurants_Opened
FROM main m
JOIN date_dim d ON m.Date = d.Date
GROUP BY d.Year, d.Quarter, d.MonthName, d.Month
ORDER BY d.Year, d.Quarter, d.Month;


-- ============================================================
-- Q6. RESTAURANT COUNT BY AVERAGE RATING
-- ============================================================
SELECT
  Rating,
  COUNT(*) AS Restaurant_Count
FROM main
GROUP BY Rating
ORDER BY Rating;


-- ============================================================
-- Q7. PRICE BUCKETS (based on Average Cost for Two, converted to USD).
-- ============================================================
SELECT
  CASE
    WHEN ROUND(m.Average_Cost_for_two * cur.USD_Rate, 2) < 5   THEN '1. Under $5'
    WHEN ROUND(m.Average_Cost_for_two * cur.USD_Rate, 2) < 10  THEN '2. $5 - $10'
    WHEN ROUND(m.Average_Cost_for_two * cur.USD_Rate, 2) < 20  THEN '3. $10 - $20'
    WHEN ROUND(m.Average_Cost_for_two * cur.USD_Rate, 2) < 50  THEN '4. $20 - $50'
    WHEN ROUND(m.Average_Cost_for_two * cur.USD_Rate, 2) < 100 THEN '5. $50 - $100'
    ELSE '6. $100+'
  END AS Price_Bucket,
  COUNT(*) AS Restaurant_Count
FROM main m
JOIN currency cur ON m.Currency = cur.Currency
GROUP BY Price_Bucket
ORDER BY Price_Bucket;


-- ============================================================
-- Q8. % OF RESTAURANTS WITH TABLE BOOKING
-- ============================================================
SELECT
  Has_Table_booking,
  COUNT(*) AS Restaurant_Count,
  ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM main), 2) AS Percentage
FROM main
GROUP BY Has_Table_booking;


-- ============================================================
-- Q9. % OF RESTAURANTS WITH ONLINE DELIVERY
-- ============================================================
SELECT
  Has_Online_delivery,
  COUNT(*) AS Restaurant_Count,
  ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM main), 2) AS Percentage
FROM main
GROUP BY Has_Online_delivery;


-- ============================================================
-- Q10. CHART-READY DATA (Cuisines, City, Ratings).
-- ============================================================

-- 10a. Restaurant count by top 15 cities (for a bar chart)
SELECT City, COUNT(*) AS Restaurant_Count
FROM main
GROUP BY City
ORDER BY Restaurant_Count DESC
LIMIT 15;

-- 10b. Average rating distribution (for a histogram)
SELECT ROUND(Rating,0) AS Rating_Rounded, COUNT(*) AS Restaurant_Count
FROM main
GROUP BY Rating_Rounded
ORDER BY Rating_Rounded;

-- 10c. Top cuisines by restaurant count and average rating.

WITH RECURSIVE cuisine_split AS (
  SELECT
    RestaurantID,
    Rating,
    TRIM(SUBSTRING_INDEX(Cuisines, ',', 1)) AS Cuisine,
    TRIM(SUBSTRING(Cuisines FROM LENGTH(SUBSTRING_INDEX(Cuisines, ',', 1)) + 2)) AS Remaining
  FROM main
  WHERE Cuisines IS NOT NULL AND Cuisines <> ''

  UNION ALL

  SELECT
    RestaurantID,
    Rating,
    TRIM(SUBSTRING_INDEX(Remaining, ',', 1)),
    TRIM(SUBSTRING(Remaining FROM LENGTH(SUBSTRING_INDEX(Remaining, ',', 1)) + 2))
  FROM cuisine_split
  WHERE Remaining <> ''
)
SELECT
  Cuisine,
  COUNT(DISTINCT RestaurantID) AS Restaurant_Count,
  ROUND(AVG(Rating), 2)        AS Avg_Rating
FROM cuisine_split
GROUP BY Cuisine
ORDER BY Restaurant_Count DESC
LIMIT 15;



